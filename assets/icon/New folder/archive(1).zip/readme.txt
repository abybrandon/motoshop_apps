Iconset: Metro UI Dock (https://www.iconfinder.com/iconsets/metro-ui-dock-icon-set--icons-by-dakirby)
Author: Dakirby309 (http://dakirby309.deviantart.com)
License: Creative Commons (Attribution 3.0 Unported) (http://creativecommons.org/licenses/by/3.0/)
Download date: 2022-02-26